import type { Listing } from "@/lib/listings";
import { specList } from "@/lib/listings";
import { PriceTag } from "@/components/price-tag";
import { usePrefs } from "@/lib/prefs";

interface ListingCardProps {
  listing: Listing;
  index: number;
  onDetails: (l: Listing) => void;
  onContact: (l: Listing) => void;
}

export function ListingCard({ listing, index, onDetails, onContact }: ListingCardProps) {
  const { lang, t, dir } = usePrefs();
  const specs = specList(listing.specs, t);

  return (
    <article
      dir={dir}
      style={{ animation: "rise 0.6s var(--ease) both", animationDelay: `${index * 60}ms` }}
      className="w-[300px] shrink-0 overflow-hidden rounded-3xl border border-border bg-card/60"
    >
      <div className="relative h-44 overflow-hidden">
        <img
          src={listing.image}
          alt={listing.title[lang]}
          className="h-full w-full object-cover transition-transform duration-700 hover:scale-105"
        />
        {listing.featured && (
          <span className="absolute top-3 right-3 rounded-full bg-brass px-2.5 py-1 text-[10px] font-bold text-primary-foreground">
            {t("featured")}
          </span>
        )}
      </div>
      <div className="space-y-2 p-4">
        <h3 className="font-display text-lg font-bold text-foreground">{listing.title[lang]}</h3>
        <p className="text-xs text-mist">{listing.location[lang]}</p>
        <div className="flex flex-wrap gap-1.5">
          {specs.map((spec, i) => (
            <span
              key={i}
              className="rounded-full border border-border bg-ivory/5 px-2.5 py-1 text-[10px] text-ivory-soft"
            >
              {spec}
            </span>
          ))}
        </div>
        <PriceTag listing={listing} />
        <div className="flex gap-2 pt-1">
          <button
            onClick={() => onDetails(listing)}
            className="flex-1 rounded-xl bg-primary py-2.5 text-xs font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
          >
            {t("details")}
          </button>
          <button
            onClick={() => onContact(listing)}
            className="flex-1 rounded-xl border border-brass/50 bg-brass/10 py-2.5 text-xs font-semibold text-brass-soft transition-colors hover:bg-brass/20"
          >
            {t("contact")}
          </button>
        </div>
      </div>
    </article>
  );
}
