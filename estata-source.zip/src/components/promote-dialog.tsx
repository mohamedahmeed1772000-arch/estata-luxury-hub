import { useState } from "react";
import { usePrefs } from "@/lib/prefs";

export function PromoteDialog({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { t, dir, fromQar, currencyName } = usePrefs();
  const [chosen, setChosen] = useState<string | null>(null);
  if (!open) return null;

  const plans = [
    { id: "free", priceQar: 0, name: t("planFree"), perks: [t("perkFree1"), t("perkFree2")] },
    {
      id: "silver",
      priceQar: 100,
      name: t("planSilver"),
      perks: [t("perkSilver1"), t("perkSilver2")],
    },
    {
      id: "gold",
      priceQar: 250,
      name: t("planGold"),
      perks: [t("perkGold1"), t("perkGold2")],
      best: true,
    },
  ];
  const plan = plans.find((p) => p.id === chosen);
  const fmt = (qar: number) => Math.round(fromQar(qar)).toLocaleString("en-US");

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-ink/80 p-4 backdrop-blur-sm sm:items-center"
      onClick={() => {
        setChosen(null);
        onClose();
      }}
    >
      <div
        dir={dir}
        className="max-h-[88vh] w-full max-w-md overflow-y-auto rounded-3xl border border-border bg-popover p-5"
        style={{ animation: "rise 0.5s var(--ease) both" }}
        onClick={(e) => e.stopPropagation()}
      >
        {plan ? (
          <div className="py-6 text-center">
            <p className="font-display text-2xl font-extrabold text-brass-soft">{t("planChosen", { p: plan.name })}</p>
            <p className="mt-2 text-sm text-ivory-soft">{t("planChosenText")}</p>
            <button
              onClick={() => {
                setChosen(null);
                onClose();
              }}
              className="mt-6 rounded-xl bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground"
            >
              {t("done")}
            </button>
          </div>
        ) : (
          <>
            <p className="text-[11px] tracking-[0.25em] text-brass">{t("investors")}</p>
            <h3 className="font-display text-2xl font-extrabold text-foreground">{t("promote")}</h3>
            <p className="mt-1 text-sm text-mist">{t("plansSub")}</p>
            <div className="mt-5 space-y-3">
              {plans.map((p) => (
                <div
                  key={p.id}
                  className={`rounded-2xl border p-4 ${p.best ? "border-brass bg-brass/10" : "border-border bg-ivory/5"}`}
                >
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="font-display text-lg font-bold text-foreground">
                        {p.name}
                        {p.best && (
                          <span className="mr-2 rounded-full bg-brass px-2 py-0.5 text-[10px] text-primary-foreground">
                            {t("mostPopular")}
                          </span>
                        )}
                      </p>
                      <ul className="mt-2 space-y-1 text-xs text-ivory-soft">
                        {p.perks.map((k) => (
                          <li key={k}>
                            <span className="text-brass">◆ </span>
                            {k}
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div className="text-left">
                      <p className="font-display text-2xl font-bold tabular-nums text-brass-soft">
                        {p.priceQar ? fmt(p.priceQar) : "0"}
                      </p>
                      <p className="text-[10px] text-mist">
                        {p.priceQar ? `${currencyName()} ${t("perMonth")}` : t("noFees")}
                      </p>
                    </div>
                  </div>
                  <button
                    onClick={() => setChosen(p.id)}
                    className="mt-3 w-full rounded-xl bg-primary py-2.5 text-xs font-semibold text-primary-foreground hover:bg-primary/90"
                  >
                    {p.id === "free" ? t("startFree") : t("choosePlan", { p: p.name })}
                  </button>
                </div>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
