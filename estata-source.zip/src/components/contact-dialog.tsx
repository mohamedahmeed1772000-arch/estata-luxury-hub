import { useEffect, useState, type FormEvent } from "react";
import type { Listing } from "@/lib/listings";
import { usePrefs } from "@/lib/prefs";

interface ContactDialogProps {
  listing: Listing | null;
  onClose: () => void;
}

const inputClass =
  "w-full rounded-xl border border-border bg-ivory/5 px-4 py-3 text-sm text-foreground placeholder:text-mist/60 transition-colors focus:border-brass focus:outline-none";

export function ContactDialog({ listing, onClose }: ContactDialogProps) {
  const { lang, t, dir } = usePrefs();
  const [sent, setSent] = useState(false);

  useEffect(() => {
    if (listing) setSent(false);
  }, [listing]);

  useEffect(() => {
    if (!listing) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [listing, onClose]);

  if (!listing) return null;

  const title = listing.title[lang];

  const submit = (e: FormEvent) => {
    e.preventDefault();
    setSent(true);
  };

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-ink/80 p-4 backdrop-blur-sm sm:items-center"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md rounded-3xl border border-border bg-popover shadow-2xl"
        style={{ animation: "rise 0.5s var(--ease) both" }}
        onClick={(e) => e.stopPropagation()}
      >
        {sent ? (
          <div dir={dir} className="p-8 text-center">
            <div className="mx-auto grid size-14 place-items-center rounded-full bg-primary/15 text-2xl text-brass">
              ✓
            </div>
            <h3 className="mt-4 font-display text-xl font-extrabold text-foreground">{t("received")}</h3>
            <p className="mt-2 text-sm leading-relaxed text-mist">{t("receivedText", { t: title })}</p>
            <button
              onClick={onClose}
              className="mt-6 w-full rounded-xl bg-primary py-3 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
            >
              {t("done")}
            </button>
          </div>
        ) : (
          <form onSubmit={submit} dir={dir} className="p-6">
            <div className="flex items-start justify-between gap-3">
              <div>
                <h3 className="font-display text-lg font-extrabold text-foreground">{t("contactUs")}</h3>
                <p className="mt-0.5 text-xs text-mist">{t("about", { t: title })}</p>
              </div>
              <button
                type="button"
                onClick={onClose}
                aria-label={t("close")}
                className="grid size-9 shrink-0 place-items-center rounded-full border border-border text-ivory-soft"
              >
                ✕
              </button>
            </div>
            <div className="mt-5 space-y-3">
              <input required placeholder={t("fullName")} className={inputClass} />
              <input required type="tel" placeholder={t("phone")} className={inputClass} />
              <textarea rows={3} placeholder={t("message")} className={inputClass} />
            </div>
            <button
              type="submit"
              className="mt-5 w-full rounded-xl bg-primary py-3 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
            >
              {t("send")}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
