import { useEffect, useRef, useState } from "react";
import type { Listing } from "@/lib/listings";
import { usePrefs } from "@/lib/prefs";
import promoVideo from "@/assets/estata-sponsor-promo.mp4.asset.json";

const AD_SECONDS = 6;

export function TourDialog({ listing, onClose }: { listing: Listing | null; onClose: () => void }) {
  const { lang, t, dir } = usePrefs();
  const [left, setLeft] = useState(AD_SECONDS);
  const [adDone, setAdDone] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);

  useEffect(() => {
    if (!listing) return;
    setLeft(AD_SECONDS);
    setAdDone(false);
    const timer = window.setInterval(() => setLeft((s) => (s > 0 ? s - 1 : 0)), 1000);
    return () => clearInterval(timer);
  }, [listing]);

  if (!listing) return null;

  return (
    <div
      className="fixed inset-0 z-[60] flex items-center justify-center bg-ink/90 p-4 backdrop-blur-sm"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md overflow-hidden rounded-3xl border border-border bg-popover"
        style={{ animation: "rise 0.5s var(--ease) both" }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="relative aspect-video overflow-hidden bg-ink">
          {!adDone ? (
            <div className="absolute inset-0 bg-ink">
              <video
                ref={videoRef}
                src={promoVideo.url}
                autoPlay
                muted
                playsInline
                onEnded={() => setAdDone(true)}
                onError={() => setAdDone(true)}
                className="h-full w-full object-cover"
              />
              <div className="pointer-events-none absolute inset-0 bg-gradient-to-t from-ink/70 via-transparent to-ink/20" />
              <span className="absolute top-3 right-3 rounded-full bg-brass px-2.5 py-1 text-[10px] font-bold text-primary-foreground">
                {t("sponsored")}
              </span>
              <span className="absolute bottom-3 left-3 rounded-lg bg-ink/75 px-3 py-1.5 text-[10px] text-ivory-soft backdrop-blur-md">
                {t("tourIn", { n: left })}
              </span>
              <p className="absolute bottom-3 right-3 font-display text-sm font-bold text-foreground">{t("presents")}</p>
            </div>
          ) : (
            <>
              <img
                src={listing.image}
                alt={listing.title[lang]}
                className="h-full w-full object-cover"
                style={{ animation: "tour 14s ease-in-out infinite alternate" }}
              />
              <span className="absolute top-3 right-3 rounded-full bg-ink/70 px-3 py-1 text-[10px] text-brass-soft backdrop-blur-md">
                {t("virtualTour")}
              </span>
            </>
          )}
        </div>
        <div dir={dir} className="flex items-center justify-between p-4">
          <div>
            <p className="font-display font-bold text-foreground">{listing.title[lang]}</p>
            <p className="text-xs text-mist">{listing.location[lang]}</p>
          </div>
          <button
            onClick={onClose}
            className="rounded-xl border border-border bg-ivory/5 px-4 py-2 text-xs text-ivory-soft hover:bg-ivory/10"
          >
            {t("close")}
          </button>
        </div>
      </div>
    </div>
  );
}
