import type { Listing } from "@/lib/listings";
import { usePrefs } from "@/lib/prefs";

export function PriceTag({ listing, size = "md" }: { listing: Listing; size?: "md" | "lg" }) {
  const { money, t, dir } = usePrefs();
  const { amount, name } = money(listing.priceValue * 1_000_000);
  return (
    <div dir={dir} className="leading-tight">
      <p
        className={
          size === "lg"
            ? "font-display text-2xl font-extrabold tabular-nums text-brass"
            : "font-display text-lg font-extrabold tabular-nums text-brass"
        }
      >
        <bdi dir="ltr">{amount}</bdi>{" "}
        <span className={size === "lg" ? "text-xs font-semibold text-mist" : "text-[10px] font-semibold text-mist"}>
          {name}
        </span>
      </p>
      {listing.priceNote && <p className="mt-0.5 text-[11px] text-mist">{t("monthly")}</p>}
    </div>
  );
}
