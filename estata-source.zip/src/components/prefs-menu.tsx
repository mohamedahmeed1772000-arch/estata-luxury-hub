import { useState } from "react";
import { createPortal } from "react-dom";
import { usePrefs, LANGS, CURRENCIES } from "@/lib/prefs";

/** Header switcher for interface language and display currency. */
export function PrefsMenu() {
  const { lang, currency, setLang, setCurrency, t, dir, currencyName } = usePrefs();
  const [open, setOpen] = useState(false);
  const current = LANGS.find((l) => l.id === lang)!;

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        aria-label={t("language")}
        className="flex items-center gap-1.5 rounded-full border border-border bg-ivory/5 px-3 py-1.5 text-[11px] font-semibold text-ivory-soft transition-colors hover:bg-ivory/10"
      >
        <span aria-hidden>🌐</span>
        <span>{current.label}</span>
      </button>

      {open &&
        createPortal(
          <div
            className="fixed inset-0 z-50 flex items-end justify-center bg-ink/80 p-4 backdrop-blur-sm sm:items-center"
            onClick={() => setOpen(false)}
          >
            <div
              dir={dir}
              className="max-h-[88vh] w-full max-w-md overflow-y-auto rounded-3xl border border-border bg-popover p-5 shadow-2xl"
              style={{ animation: "rise 0.5s var(--ease) both" }}
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-start justify-between">
                <h3 className="font-display text-xl font-extrabold text-foreground">{t("menu")}</h3>
                <button
                  onClick={() => setOpen(false)}
                  aria-label={t("close")}
                  className="grid size-9 place-items-center rounded-full bg-ivory/5 text-ivory"
                >
                  ✕
                </button>
              </div>

              <p className="mt-4 text-[11px] tracking-[0.25em] text-brass">{t("language")}</p>
              <div className="mt-2 grid grid-cols-2 gap-2">
                {LANGS.map((l) => (
                  <button
                    key={l.id}
                    onClick={() => setLang(l.id)}
                    className={
                      l.id === lang
                        ? "rounded-xl border border-brass bg-brass/10 px-3 py-2.5 text-sm font-semibold text-brass-soft"
                        : "rounded-xl border border-border bg-ivory/5 px-3 py-2.5 text-sm text-ivory-soft transition-colors hover:bg-ivory/10"
                    }
                  >
                    {l.label}
                  </button>
                ))}
              </div>

              <p className="mt-5 text-[11px] tracking-[0.25em] text-brass">{t("currency")}</p>
              <div className="mt-2 grid grid-cols-2 gap-2">
                {CURRENCIES.map((c) => (
                  <button
                    key={c}
                    onClick={() => setCurrency(c)}
                    className={
                      c === currency
                        ? "rounded-xl border border-brass bg-brass/10 px-3 py-2.5 text-sm font-semibold text-brass-soft"
                        : "rounded-xl border border-border bg-ivory/5 px-3 py-2.5 text-sm text-ivory-soft transition-colors hover:bg-ivory/10"
                    }
                  >
                    {currencyName(c)}
                  </button>
                ))}
              </div>
            </div>
          </div>,
          document.body,
        )}
    </>
  );
}
