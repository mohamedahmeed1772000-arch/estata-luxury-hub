import { useState } from "react";
import { createPortal } from "react-dom";
import { useServerFn } from "@tanstack/react-start";
import { listings, type Listing } from "@/lib/listings";
import { findByBudget } from "@/lib/budget.functions";
import { PriceTag } from "@/components/price-tag";
import { usePrefs } from "@/lib/prefs";

export function BudgetAssistant({ onDetails }: { onDetails: (l: Listing) => void }) {
  const { lang, t, dir, money } = usePrefs();
  const [open, setOpen] = useState(false);
  const [budget, setBudget] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<{ budgetQar: number; items: Listing[]; summary: string } | null>(null);
  const run = useServerFn(findByBudget);

  const examples = [t("ex1"), t("ex2"), t("ex3")];

  async function submit(text = budget) {
    if (!text.trim() || loading) return;
    setBudget(text);
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      const catalog = listings.map((l) => ({
        id: l.id,
        type: l.type,
        title: l.title[lang] ?? l.title.en,
        priceQar: Math.round(l.priceValue * 1_000_000),
        monthly: l.type === "rent",
      }));
      const r = await run({ data: { budget: text, catalog } });
      setResult({
        budgetQar: r.budgetQar,
        summary: r.summary,
        items: listings.filter((l) => r.matchIds.includes(l.id)),
      });
    } catch (e) {
      setError(e instanceof Error ? e.message : t("errGeneric"));
    } finally {
      setLoading(false);
    }
  }

  const bm = result ? money(result.budgetQar) : null;

  return (
    <>
      <button
        onClick={() => setOpen(true)}
        className="mt-3 flex w-full items-center justify-between rounded-2xl border border-brass/40 bg-brass/10 px-4 py-3 transition-colors hover:bg-brass/15"
      >
        <span>
          <span className="block font-display text-sm font-bold text-brass-soft">{t("budgetTitle")}</span>
          <span className="block text-[11px] text-mist">{t("budgetSub")}</span>
        </span>
        <span className="text-brass">←</span>
      </button>

      {open &&
        createPortal(
          <div
            className="fixed inset-0 z-50 flex items-end justify-center bg-ink/80 p-4 backdrop-blur-sm sm:items-center"
            onClick={() => setOpen(false)}
          >
            <div
              dir={dir}
              className="max-h-[88vh] w-full max-w-md overflow-y-auto rounded-3xl border border-border bg-popover p-5 shadow-2xl"
              style={{ animation: "rise 0.5s var(--ease) both" }}
              onClick={(e) => e.stopPropagation()}
            >
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-[11px] tracking-[0.25em] text-brass">{t("budgetKicker")}</p>
                  <h3 className="font-display text-2xl font-bold text-foreground">{t("budgetTitle")}</h3>
                </div>
                <button
                  onClick={() => setOpen(false)}
                  aria-label={t("close")}
                  className="grid size-9 place-items-center rounded-full bg-ivory/5 text-ivory"
                >
                  ✕
                </button>
              </div>

              <form
                className="mt-4 flex gap-2"
                onSubmit={(e) => {
                  e.preventDefault();
                  submit();
                }}
              >
                <input
                  autoFocus
                  value={budget}
                  onChange={(e) => setBudget(e.target.value)}
                  placeholder={t("budgetPh")}
                  className="w-full rounded-xl border border-border bg-ink/40 px-4 py-3 text-sm text-foreground placeholder:text-mist/60 focus:border-brass/60 focus:outline-none"
                />
                <button
                  type="submit"
                  disabled={loading || !budget.trim()}
                  className="shrink-0 rounded-xl bg-primary px-5 text-sm font-semibold text-primary-foreground disabled:opacity-50"
                >
                  {t("search")}
                </button>
              </form>

              <div className="no-scrollbar mt-3 flex gap-2 overflow-x-auto">
                {examples.map((ex) => (
                  <button
                    key={ex}
                    onClick={() => submit(ex)}
                    className="shrink-0 rounded-full border border-border bg-ivory/5 px-3 py-1.5 text-[11px] text-ivory-soft hover:bg-ivory/10"
                  >
                    {ex}
                  </button>
                ))}
              </div>

              {loading && <p className="mt-6 animate-pulse text-center text-sm text-brass-soft">{t("searching")}</p>}
              {error && <p className="mt-6 rounded-xl bg-destructive/15 p-3 text-sm text-destructive">{error}</p>}

              {result && bm && (
                <div className="mt-6">
                  <p className="text-xs text-mist">
                    {t("yourBudget")}{" "}
                    <span className="font-display text-base font-bold text-brass-soft">
                      <bdi dir="ltr">{bm.amount}</bdi> {bm.name}
                    </span>
                  </p>
                  <p className="mt-2 text-sm text-ivory-soft">{result.summary}</p>
                  <div className="mt-4 space-y-3">
                    {result.items.length === 0 && <p className="text-center text-sm text-mist">{t("noBudgetMatch")}</p>}
                    {result.items.map((l) => (
                      <button
                        key={l.id}
                        onClick={() => {
                          setOpen(false);
                          onDetails(l);
                        }}
                        className="flex w-full items-center gap-3 rounded-2xl border border-border bg-card/50 p-2 text-right hover:bg-card"
                      >
                        <img src={l.image} alt={l.title[lang]} className="size-16 rounded-xl object-cover" />
                        <div className="flex-1">
                          <p className="font-display text-sm font-bold text-foreground">{l.title[lang]}</p>
                          <PriceTag listing={l} />
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
          </div>,
          document.body,
        )}
    </>
  );
}
