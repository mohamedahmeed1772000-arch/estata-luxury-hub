import { useEffect } from "react";
import type { Listing } from "@/lib/listings";
import { specList } from "@/lib/listings";
import { PriceTag } from "@/components/price-tag";
import { usePrefs } from "@/lib/prefs";

interface DetailsDialogProps {
  listing: Listing | null;
  onClose: () => void;
  onTour: (l: Listing) => void;
  onContact: (l: Listing) => void;
}

export function DetailsDialog({ listing, onClose, onTour, onContact }: DetailsDialogProps) {
  const { lang, t, dir } = usePrefs();

  useEffect(() => {
    if (!listing) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [listing, onClose]);

  useEffect(() => {
    if (listing) document.body.style.overflow = "hidden";
    else document.body.style.overflow = "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [listing]);

  if (!listing) return null;

  return (
    <div
      className="fixed inset-0 z-50 flex items-end justify-center bg-ink/80 p-4 backdrop-blur-sm sm:items-center"
      onClick={onClose}
    >
      <div
        className="max-h-[88vh] w-full max-w-md overflow-y-auto rounded-3xl border border-border bg-popover shadow-2xl"
        style={{ animation: "rise 0.5s var(--ease) both" }}
        onClick={(e) => e.stopPropagation()}
      >
        <div className="relative h-56">
          <img src={listing.image} alt={listing.title[lang]} className="h-full w-full object-cover" />
          <button
            onClick={onClose}
            aria-label={t("close")}
            className="absolute top-3 left-3 grid size-9 place-items-center rounded-full bg-ink/60 text-ivory backdrop-blur-md"
          >
            ✕
          </button>
          {listing.featured && (
            <span className="absolute top-3 right-3 rounded-full bg-brass px-2.5 py-1 text-[10px] font-bold text-primary-foreground">
              {t("featured")}
            </span>
          )}
        </div>
        <div dir={dir} className="space-y-4 p-5">
          <div>
            <h3 className="font-display text-2xl font-extrabold text-foreground">{listing.title[lang]}</h3>
            <p className="mt-1 text-xs text-mist">{listing.location[lang]}</p>
          </div>
          <PriceTag listing={listing} size="lg" />
          <div className="flex flex-wrap gap-2">
            {specList(listing.specs, t).map((spec, i) => (
              <span
                key={i}
                className="rounded-full border border-border bg-ivory/5 px-3 py-1.5 text-[11px] text-ivory-soft"
              >
                {spec}
              </span>
            ))}
          </div>
          <p className="text-sm leading-relaxed text-ivory-soft">{listing.description[lang]}</p>
          <div className="flex gap-2 pt-1">
            <button
              onClick={() => onContact(listing)}
              className="flex-1 rounded-xl bg-primary py-3 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
            >
              {t("contactUs")}
            </button>
            <button
              onClick={() => onTour(listing)}
              className="flex-1 rounded-xl border border-brass/50 bg-brass/10 py-3 text-sm font-semibold text-brass-soft transition-colors hover:bg-brass/20"
            >
              {t("watchTour")}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
