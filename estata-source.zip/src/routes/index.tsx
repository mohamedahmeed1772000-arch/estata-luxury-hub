import { useMemo, useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { heroImage, listings, type Listing } from "@/lib/listings";
import { ListingCard } from "@/components/listing-card";
import { DetailsDialog } from "@/components/details-dialog";
import { ContactDialog } from "@/components/contact-dialog";
import { BudgetAssistant } from "@/components/budget-assistant";
import { TourDialog } from "@/components/tour-dialog";
import { PromoteDialog } from "@/components/promote-dialog";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "إستاتا | عقارات وسيارات فاخرة" },
      {
        name: "description",
        content:
          "إستاتا — منصة فاخرة للعقارات والسيارات: عقارات للبيع والإيجار وسيارات فاخرة مختارة بعناية.",
      },
      { property: "og:title", content: "إستاتا | عقارات وسيارات فاخرة" },
      {
        property: "og:description",
        content: "منصة فاخرة للعقارات والسيارات — عقارات للبيع والإيجار وسيارات فاخرة مختارة بعناية.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const chips = [
  { id: "all", label: "الكل" },
  { id: "sale", label: "للبيع" },
  { id: "rent", label: "للإيجار" },
  { id: "car", label: "سيارات" },
  { id: "premium", label: "فوق ٥ ملايين" },
] as const;

type ChipId = (typeof chips)[number]["id"];

const sections = [
  { num: "٠١", title: "عقارات للبيع", type: "sale" as const },
  { num: "٠٢", title: "عقارات للإيجار", type: "rent" as const },
  { num: "٠٣", title: "سيارات فاخرة", type: "car" as const },
];

function Index() {
  const [query, setQuery] = useState("");
  const [chip, setChip] = useState<ChipId>("all");
  const [details, setDetails] = useState<Listing | null>(null);
  const [contact, setContact] = useState<Listing | null>(null);
  const [tour, setTour] = useState<Listing | null>(null);
  const [promote, setPromote] = useState(false);

  const filtered = useMemo(() => {
    const q = query.trim();
    return listings.filter((l) => {
      if (chip === "sale" && l.type !== "sale") return false;
      if (chip === "rent" && l.type !== "rent") return false;
      if (chip === "car" && l.type !== "car") return false;
      if (chip === "premium" && !(l.type === "sale" && l.priceValue >= 5)) return false;
      if (
        q &&
        !`${l.title} ${l.location} ${l.description}`.includes(q)
      )
        return false;
      return true;
    });
  }, [query, chip]);

  return (
    <div className="min-h-screen bg-ink font-body text-ivory selection:bg-brass/30">
      {/* ambient light */}
      <div className="pointer-events-none fixed inset-0 -z-10">
        <div className="absolute -top-24 right-[-10%] size-[420px] rounded-full bg-brass/20 blur-[90px]" />
        <div className="absolute top-1/3 left-[-15%] size-[360px] rounded-full bg-ivory/10 blur-[100px]" />
        <div className="absolute bottom-0 right-1/4 size-[300px] rounded-full bg-brass/10 blur-[80px]" />
      </div>

      {/* nav */}
      <header className="sticky top-0 z-30 border-b border-border bg-ink/55 backdrop-blur-xl">
        <div className="flex items-center justify-between px-5 py-4">
          <div className="flex items-center gap-2.5">
            <span className="grid size-9 place-items-center rounded-full border border-brass/40 bg-brass/10 font-display text-lg font-extrabold text-brass">
              إ
            </span>
            <div className="leading-none">
              <p className="font-display text-lg font-extrabold tracking-tight">إستاتا</p>
              <p className="text-[10px] tracking-[0.2em] text-mist">ESTATA</p>
            </div>
          </div>
          <button
            onClick={() => setPromote(true)}
            className="rounded-full border border-brass/50 bg-brass/10 px-3 py-1.5 text-[11px] font-semibold text-brass-soft hover:bg-brass/20"
          >
              ميز عقارك الآن
          </button>
        </div>
      </header>

      {/* hero: full-bleed image + frosted search */}
      <section className="relative">
        <div className="relative h-[440px] w-full overflow-hidden">
          <img
            src={heroImage}
            alt="فيلا زجاجية عصرية عند الغروب"
            className="animate-fade absolute inset-0 h-full w-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-ink via-ink/40 to-transparent" />
          <div className="absolute inset-x-0 bottom-0 p-5 pb-28">
            <p className="animate-fade mb-2 text-[11px] tracking-[0.3em] text-brass-soft">مجموعات خاصة</p>
            <h1 className="animate-rise font-display text-4xl font-extrabold leading-[1.15] text-balance text-foreground">
              عقار يروى،
              <br />
              وسيارة تروى
            </h1>
            <p className="animate-rise mt-3 max-w-[30ch] text-sm text-pretty text-ivory-soft/90">
              مجموعات محدودة من العقارات والسيارات الفاخرة، منتقاة بعناية ككتالوج خاص.
            </p>
          </div>
        </div>

        {/* frosted search panel */}
        <div className="relative z-10 -mt-16 px-5">
          <div className="animate-rise rounded-3xl border border-border bg-ivory/10 p-4 shadow-[0_20px_60px_-20px_rgba(0,0,0,0.6)] backdrop-blur-2xl">
            <div className="flex items-center gap-2 rounded-2xl border border-border bg-ink/40 px-4 py-3.5">
              <span className="text-brass">◈</span>
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="ابحث عن فيلا، شقة، أو سيارة فاخرة…"
                className="w-full bg-transparent text-sm text-foreground placeholder:text-mist/60 focus:outline-none"
              />
              {query && (
                <button
                  onClick={() => setQuery("")}
                  aria-label="مسح البحث"
                  className="shrink-0 text-mist hover:text-ivory"
                >
                  ✕
                </button>
              )}
            </div>
            <div className="no-scrollbar mt-3 flex gap-2 overflow-x-auto pb-1">
              {chips.map((c) => (
                <button
                  key={c.id}
                  onClick={() => setChip(c.id)}
                  className={
                    chip === c.id
                      ? "shrink-0 rounded-full bg-primary px-4 py-2 text-xs font-semibold text-primary-foreground"
                      : "shrink-0 rounded-full border border-border bg-ivory/5 px-4 py-2 text-xs text-ivory-soft transition-colors hover:bg-ivory/10"
                  }
                >
                  {c.label}
                </button>
              ))}
            </div>
            <BudgetAssistant onDetails={setDetails} />
          </div>
        </div>
      </section>

      {/* listing sections */}
      {sections.map((section) => {
        const items = filtered
          .filter((l) => l.type === section.type)
          .sort((a, b) => Number(!!b.featured) - Number(!!a.featured));
        if (items.length === 0) return null;
        return (
          <section key={section.type} className="px-5 pt-12">
            <div className="mb-5 flex items-end justify-between">
              <div>
                <p className="text-[11px] tracking-[0.25em] text-brass">{section.num}</p>
                <h2 className="font-display text-2xl font-extrabold tracking-tight text-foreground">
                  {section.title}
                </h2>
              </div>
              <span className="text-xs text-mist">
                {items.length === 1 ? "عرض واحد" : `${items.length} عروض`}
              </span>
            </div>
            <div className="no-scrollbar -mx-5 flex gap-4 overflow-x-auto px-5 pb-2">
              {items.map((listing, i) => (
                <ListingCard
                  key={listing.id}
                  listing={listing}
                  index={i}
                  onDetails={setDetails}
                  onContact={setContact}
                />
              ))}
            </div>
          </section>
        );
      })}

      {filtered.length === 0 && (
        <div className="px-5 py-16 text-center">
          <p className="font-display text-lg font-bold text-foreground">لا توجد نتائج مطابقة</p>
          <p className="mt-2 text-sm text-mist">جرب كلمة بحث أخرى أو أعد ضبط عوامل التصفية.</p>
          <button
            onClick={() => {
              setQuery("");
              setChip("all");
            }}
            className="mt-6 rounded-xl bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90"
          >
            إعادة الضبط
          </button>
        </div>
      )}

      {/* promote CTA */}
      <section className="px-5 pt-14">
        <div className="rounded-3xl border border-brass/40 bg-gradient-to-br from-brass/15 to-transparent p-6">
          <p className="text-[11px] tracking-[0.25em] text-brass">للمستثمرين والبائعين</p>
          <h2 className="mt-1 font-display text-2xl font-extrabold text-foreground">ميز عقارك الآن</h2>
          <p className="mt-2 text-sm text-ivory-soft">انشر مجانا، أو اختر خطة مدفوعة تمنح عقارك أولوية أكبر ابتداء من 100 ريال قطري شهريا.</p>
          <button
            onClick={() => setPromote(true)}
            className="mt-5 rounded-xl bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground hover:bg-primary/90"
          >
            عرض خطط الأسعار
          </button>
        </div>
      </section>

      {/* footer */}
      <footer className="mt-14 border-t border-border px-5 py-8 text-center">
        <p className="font-display text-lg font-extrabold tracking-tight text-foreground">إستاتا</p>
        <p className="mt-1 text-[11px] text-mist">مجموعات خاصة للعقار والسيارة · © ٢٠٢٦</p>
      </footer>

      <DetailsDialog
        listing={details}
        onClose={() => setDetails(null)}
        onTour={setTour}
        onContact={(l) => {
          setDetails(null);
          setContact(l);
        }}
      />
      <ContactDialog listing={contact} onClose={() => setContact(null)} />
      <TourDialog listing={tour} onClose={() => setTour(null)} />
      <PromoteDialog open={promote} onClose={() => setPromote(false)} />
    </div>
  );
}
