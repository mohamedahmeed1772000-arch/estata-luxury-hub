import { createServerFn } from "@tanstack/react-start";
import { createOpenAI } from "@ai-sdk/openai";
import { streamText, Output, NoObjectGeneratedError } from "ai";
import { z } from "zod";

const Input = z.object({
  budget: z.string().min(1).max(200),
  catalog: z
    .array(
      z.object({
        id: z.string(),
        type: z.enum(["sale", "rent", "car"]),
        title: z.string(),
        priceQar: z.number(),
        monthly: z.boolean(),
      }),
    )
    .max(50),
});

const Schema = z.object({
  budgetQar: z.number(),
  matchIds: z.array(z.string()),
  summary: z.string(),
});

export const findByBudget = createServerFn({ method: "POST" })
  .inputValidator((d: unknown) => Input.parse(d))
  .handler(async ({ data }) => {
    const key = process.env["LOVABLE_API_KEY"];
    if (!key) throw new Error("خدمة الذكاء الاصطناعي غير مهيأة");

    const lovable = createOpenAI({
      baseURL: "https://ai.gateway.lovable.dev/v1",
      apiKey: key,
      headers: { "Lovable-API-Key": key, "X-Lovable-AIG-SDK": "vercel-ai-sdk" },
    });

    try {
      const result = streamText({
        model: lovable.responses("openai/gpt-6-astra"),
        output: Output.object({ schema: Schema }),
        system:
          "أنت مستشار ميزانية لمنصة إستاتا الفاخرة. العملة الأساسية ريال قطري. حوّل ميزانية المستخدم إلى رقم بالريال القطري (إن ذكر عملة أخرى حوّلها تقريبياً: الريال السعودي≈0.97 ريال قطري، الدولار≈3.64، الجنيه المصري≈0.075). إن ذكر ميزانية شهرية أو إيجار فقارنها بالعروض الشهرية، وإلا قارن مع سعر الشراء. أعد فقط معرفات العروض التي سعرها لا يتجاوز الميزانية. اكتب ملخصاً عربياً قصيراً راقياً (جملتان كحد أقصى) بدون تشكيل.",
        prompt: `ميزانية المستخدم: ${data.budget}\n\nالعروض:\n${JSON.stringify(data.catalog)}`,
        providerOptions: {
          openai: {
            forceReasoning: true,
            reasoningEffort: "low",
            store: false,
            include: ["reasoning.encrypted_content"],
          },
        },
      });
      const out = await result.output;
      // Enforce exact budget server-side
      const valid = new Set(data.catalog.map((c) => c.id));
      const matchIds = out.matchIds.filter((id) => {
        const c = data.catalog.find((x) => x.id === id);
        return valid.has(id) && c && c.priceQar <= out.budgetQar;
      });
      return { budgetQar: out.budgetQar, matchIds, summary: out.summary };
    } catch (e) {
      if (NoObjectGeneratedError.isInstance(e)) {
        throw new Error("لم نتمكن من فهم الميزانية، جرّب كتابتها بالأرقام");
      }
      const status = (e as { statusCode?: number }).statusCode;
      if (status === 429) throw new Error("طلبات كثيرة، حاول بعد لحظات");
      if (status === 402) throw new Error("نفد رصيد الذكاء الاصطناعي لهذا المشروع");
      throw e;
    }
  });
