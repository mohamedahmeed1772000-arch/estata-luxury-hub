import heroImg from "@/assets/hero.jpg";
import villaImg from "@/assets/villa-sale.jpg";
import penthouseImg from "@/assets/penthouse.jpg";
import townhouseImg from "@/assets/townhouse.jpg";
import apartmentImg from "@/assets/apartment-rent.jpg";
import duplexImg from "@/assets/duplex-rent.jpg";
import sedanImg from "@/assets/sedan.jpg";
import suvImg from "@/assets/suv.jpg";
import type { Lang } from "@/lib/prefs";

export type ListingType = "sale" | "rent" | "car";

type Text = Record<Lang, string>;

export type Specs =
  | { kind: "home"; rooms: number; area: number; parking: number }
  | { kind: "car"; year: number; km: number; cyl: number };

export interface Listing {
  id: string;
  type: ListingType;
  title: Text;
  location: Text;
  description: Text;
  /** In millions of Qatari riyals (catalog base). */
  priceValue: number;
  priceNote?: boolean;
  specs: Specs;
  image: string;
  featured?: boolean;
}

const featuredIds = new Set(["penthouse-marina", "duplex-pearl", "car-suv"]);

export const heroImage = heroImg;

const doha = (d: string): Text => ({
  ar: `${d}، الدوحة`,
  en: `${d}, Doha`,
  fr: `${d}, Doha`,
  es: `${d}, Doha`,
  tr: `${d}, Doha`,
});
const model = (y: number): Text => ({
  ar: `موديل ${y}`,
  en: `${y} model`,
  fr: `Modèle ${y}`,
  es: `Modelo ${y}`,
  tr: `${y} model`,
});

const rawListings: Listing[] = [
  {
    id: "villa-pearl",
    type: "sale",
    title: { ar: "فيلا اللؤلؤة", en: "The Pearl Villa", fr: "Villa La Perle", es: "Villa La Perla", tr: "İnci Villası" },
    location: { ...doha("The Pearl"), ar: "الجزيرة اللؤلؤية، الدوحة" },
    priceValue: 7.5,
    specs: { kind: "home", rooms: 6, area: 450, parking: 4 },
    image: villaImg,
    description: {
      ar: "فيلا عصرية بتصميم معماري مميز على الواجهة البحرية، مع مسبح لا متناهي وحديقة خاصة وغرفة سينما منزلية، جاهزة للسكن الفوري.",
      en: "A modern waterfront villa with striking architecture, an infinity pool, private garden and home cinema — ready to move in.",
      fr: "Villa moderne en front de mer à l’architecture remarquable, piscine à débordement, jardin privé et salle de cinéma.",
      es: "Villa moderna frente al mar con arquitectura singular, piscina infinita, jardín privado y sala de cine.",
      tr: "Deniz kenarında etkileyici mimariye sahip modern villa; sonsuzluk havuzu, özel bahçe ve ev sineması.",
    },
  },
  {
    id: "penthouse-marina",
    type: "sale",
    title: { ar: "بنتهاوس المارينا", en: "Marina Penthouse", fr: "Penthouse Marina", es: "Ático Marina", tr: "Marina Çatı Katı" },
    location: { ...doha("Al Wakrah"), ar: "الوكرة، الدوحة" },
    priceValue: 12,
    specs: { kind: "home", rooms: 4, area: 320, parking: 3 },
    image: penthouseImg,
    description: {
      ar: "بنتهاوس بإطلالة بانورامية على المارينا، تشطيبات رخامية إيطالية، مصعد خاص، وشرفة واسعة تطل على أفق المدينة.",
      en: "Penthouse with panoramic marina views, Italian marble finishes, a private lift and a wide terrace over the skyline.",
      fr: "Penthouse avec vue panoramique sur la marina, marbre italien, ascenseur privé et grande terrasse.",
      es: "Ático con vistas panorámicas a la marina, acabados en mármol italiano, ascensor privado y amplia terraza.",
      tr: "Marinaya panoramik manzaralı, İtalyan mermeri, özel asansör ve geniş teraslı çatı katı.",
    },
  },
  {
    id: "villa-yasmin",
    type: "sale",
    title: { ar: "فيلا الياسمين", en: "Jasmine Villa", fr: "Villa Jasmin", es: "Villa Jazmín", tr: "Yasemin Villası" },
    location: { ...doha("Al Kharaitiyat"), ar: "الخريطيات، الدوحة" },
    priceValue: 4.2,
    specs: { kind: "home", rooms: 3, area: 210, parking: 2 },
    image: townhouseImg,
    description: {
      ar: "فيلا دافئة الطابع بواجهة حجرية ومدخل مقوس، حديقة خلفية هادئة، ومطبخ مفتوح مجهز بالكامل بأحدث الأجهزة.",
      en: "A warm stone-fronted villa with an arched entrance, calm back garden and a fully equipped open kitchen.",
      fr: "Villa chaleureuse en pierre avec entrée voûtée, jardin paisible et cuisine ouverte entièrement équipée.",
      es: "Villa cálida de fachada de piedra con entrada en arco, jardín tranquilo y cocina abierta equipada.",
      tr: "Taş cepheli, kemerli girişli, sakin bahçeli ve tam donanımlı açık mutfaklı sıcak bir villa.",
    },
  },
  {
    id: "apt-marina",
    type: "rent",
    title: { ar: "شقة المارينا", en: "Marina Apartment", fr: "Appartement Marina", es: "Piso Marina", tr: "Marina Dairesi" },
    location: { ...doha("Al Wakrah"), ar: "الوكرة، الدوحة" },
    priceValue: 0.055,
    priceNote: true,
    specs: { kind: "home", rooms: 3, area: 180, parking: 2 },
    image: apartmentImg,
    description: {
      ar: "شقة فاخرة مشرقة بأرضيات رخامية ونوافذ ممتدة، مدخل خاص، وصالة رياضية ومسبح مشترك داخل المجمع المغلق.",
      en: "A bright luxury apartment with marble floors, full-height windows, private entrance, gym and shared pool.",
      fr: "Appartement lumineux, sols en marbre, grandes baies, entrée privée, salle de sport et piscine.",
      es: "Piso luminoso con suelos de mármol, grandes ventanales, entrada privada, gimnasio y piscina.",
      tr: "Mermer zeminli, geniş pencereli, özel girişli, spor salonu ve ortak havuzlu aydınlık lüks daire.",
    },
  },
  {
    id: "duplex-pearl",
    type: "rent",
    title: { ar: "دوبلكس اللؤلؤة", en: "Pearl Duplex", fr: "Duplex La Perle", es: "Dúplex La Perla", tr: "İnci Dubleks" },
    location: { ...doha("The Pearl"), ar: "الجزيرة اللؤلؤية، الدوحة" },
    priceValue: 0.08,
    priceNote: true,
    specs: { kind: "home", rooms: 4, area: 260, parking: 3 },
    image: duplexImg,
    description: {
      ar: "دوبلكس بسقف مزدوج الارتفاع وخشب دافئ، تراس واسع بإطلالة على الواجهة البحرية، وخدمات كونسيرج على مدار الساعة.",
      en: "Double-height duplex in warm wood, a wide terrace facing the waterfront and 24/7 concierge.",
      fr: "Duplex double hauteur en bois chaleureux, grande terrasse face à la mer et conciergerie 24h/24.",
      es: "Dúplex de doble altura en madera cálida, gran terraza frente al mar y conserjería 24 h.",
      tr: "Çift yükseklikte sıcak ahşap dubleks, deniz manzaralı geniş teras ve 7/24 konsiyerj.",
    },
  },
  {
    id: "car-sedan",
    type: "car",
    title: { ar: "سيدان السفير", en: "Ambassador Sedan", fr: "Berline Ambassadeur", es: "Sedán Embajador", tr: "Büyükelçi Sedan" },
    location: model(2024),
    priceValue: 0.98,
    specs: { kind: "car", year: 2024, km: 500, cyl: 6 },
    image: sedanImg,
    description: {
      ar: "سيدان فاخرة بلون أسود لامع في حالة الوكالة، مقصورة جلدية بتهوية ونظام صوت راق، مع ضمان شامل ساري.",
      en: "A gloss-black luxury sedan in showroom condition, ventilated leather cabin, premium audio and full warranty.",
      fr: "Berline de luxe noir brillant, état neuf, cuir ventilé, audio haut de gamme et garantie complète.",
      es: "Sedán de lujo negro brillante como nuevo, cuero ventilado, audio premium y garantía completa.",
      tr: "Parlak siyah, sıfır ayarında lüks sedan; havalandırmalı deri, premium ses sistemi ve tam garanti.",
    },
  },
  {
    id: "car-suv",
    type: "car",
    title: { ar: "جي إكس الرحاب", en: "GX Horizon", fr: "GX Horizon", es: "GX Horizon", tr: "GX Horizon" },
    location: model(2023),
    priceValue: 1.4,
    specs: { kind: "car", year: 2023, km: 1200, cyl: 8 },
    image: suvImg,
    description: {
      ar: "دفع رباعي فاخر بلون رمادي مطفي، مقصورة سبعة مقاعد بشاشات خلفية، وسجل صيانة كامل بحالة استخدام دقيقة.",
      en: "A matte-grey luxury 4x4 with seven seats, rear screens and a full service history.",
      fr: "4x4 de luxe gris mat, sept places, écrans arrière et historique d’entretien complet.",
      es: "4x4 de lujo gris mate, siete plazas, pantallas traseras e historial de mantenimiento completo.",
      tr: "Mat gri lüks 4x4; yedi koltuk, arka ekranlar ve eksiksiz bakım geçmişi.",
    },
  },
];

export const listings: Listing[] = rawListings.map((l) => ({ ...l, featured: featuredIds.has(l.id) }));

export function specList(s: Specs, t: (k: string, v?: Record<string, string | number>) => string) {
  const n = (x: number) => x.toLocaleString("en-US");
  return s.kind === "home"
    ? [t("rooms", { n: s.rooms }), t("sqm", { n: n(s.area) }), t("parking", { n: s.parking })]
    : [String(s.year), t("km", { n: n(s.km) }), t("cyl", { n: s.cyl })];
}
